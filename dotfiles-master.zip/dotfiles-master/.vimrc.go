set runtimepath^="/Users/wmckettr"
source /Users/wmckettr/.vimrc-go/basic.vim
source /Users/wmckettr/.vimrc-go/filetypes.vim
source /Users/wmckettr/.vimrc-go/plugins.vim
source /Users/wmckettr/.vimrc-go/extended.vim
try
  source /Users/wmckettr/custom_config.vim
catch
endtry
