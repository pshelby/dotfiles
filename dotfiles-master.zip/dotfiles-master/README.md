
```
./bootstrap.sh
cd fonts
./install.sh
cd ..
```

pip install powerline-status

